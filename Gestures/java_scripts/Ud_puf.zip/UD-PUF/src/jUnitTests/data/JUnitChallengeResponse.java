package jUnitTests.data;

import static org.junit.Assert.*;

import org.junit.Test;

public class JUnitChallengeResponse {

    @Test
    public void test() {
	fail("Not yet implemented");
    }

}
