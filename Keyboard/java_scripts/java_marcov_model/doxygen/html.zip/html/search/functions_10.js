var searchData=
[
  ['window',['Window',['../classcomponents_1_1_window.html#a7ca5acd9fe649949cb0adccc837cf9d2',1,'components.Window.Window(List&lt; Touch &gt; touches)'],['../classcomponents_1_1_window.html#a5869fe4e3c5d711af934ff83114e55aa',1,'components.Window.Window(Window w)']]]
];
