var searchData=
[
  ['data_5fanalysis',['data_analysis',['../namespacedata__analysis.html',1,'']]],
  ['distribution',['Distribution',['../classcomponents_1_1_distribution.html#a0aef5c1c0f3732a9acc45001a251f345',1,'components.Distribution.Distribution(List&lt; Touch &gt; touches)'],['../classcomponents_1_1_distribution.html#a5c1988b4cf235e87955df659df3e15b0',1,'components.Distribution.Distribution(List&lt; Touch &gt; touches, int keycode)'],['../classcomponents_1_1_distribution.html#ab388f6790c565f71f29dc00cfdbd14fb',1,'components.Distribution.Distribution(Distribution d)'],['../enumtest_1_1_main_1_1_test_files_1_1_distribution.html#ad84ae1cbad53377ee9baf4f306a6d52f',1,'test.Main.TestFiles.Distribution.Distribution()'],['../enumruntime_1_1_operation__thread_1_1_computation.html#a6381fe8b51eee311dff627d315fefbfd',1,'runtime.Operation_thread.Computation.DISTRIBUTION()']]],
  ['distribution',['Distribution',['../classcomponents_1_1_distribution.html',1,'components']]],
  ['distribution',['Distribution',['../enumtest_1_1_main_1_1_test_files_1_1_distribution.html',1,'test::Main::TestFiles']]],
  ['distribution_2ejava',['Distribution.java',['../_distribution_8java.html',1,'']]]
];
