var searchData=
[
  ['data_5fanalysis',['data_analysis',['../namespacedata__analysis.html',1,'']]]
];
