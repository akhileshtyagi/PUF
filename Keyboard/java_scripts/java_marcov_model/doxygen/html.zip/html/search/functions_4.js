var searchData=
[
  ['equal_5ffalse_5fpositive_5fnegative_5fauthentication_5fpercentage',['equal_false_positive_negative_authentication_percentage',['../classdata__analysis_1_1_statistics.html#a7702c206ace91fa095d5b68a24820db2',1,'data_analysis::Statistics']]],
  ['equals',['equals',['../classcomponents_1_1_distribution.html#a1b4f8a098ddc5f1fef43d6ecd95b6832',1,'components.Distribution.equals()'],['../classcomponents_1_1_token.html#a9d029725d9c98ef58017aee36be0989d',1,'components.Token.equals()']]],
  ['exit',['exit',['../classgui_1_1_start_g_u_i.html#a92880df89c85411e12e66594bc0c011d',1,'gui::StartGUI']]]
];
