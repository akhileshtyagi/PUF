var searchData=
[
  ['failure',['FAILURE',['../enumruntime_1_1_chain_builder_1_1_state.html#a97d260e443bed75f55f643efa323c3f4',1,'runtime::ChainBuilder::State']]],
  ['false_5fnegative_5fpercentage',['false_negative_percentage',['../classdata__analysis_1_1_statistics.html#abcd420f8186babaf12e030180e4c458d',1,'data_analysis::Statistics']]],
  ['false_5fpositive_5fpercentage',['false_positive_percentage',['../classdata__analysis_1_1_statistics.html#a0c7f157e53361c33276290383acff9b6',1,'data_analysis::Statistics']]]
];
