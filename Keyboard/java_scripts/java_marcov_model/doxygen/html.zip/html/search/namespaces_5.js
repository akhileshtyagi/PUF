var searchData=
[
  ['test',['test',['../namespacetest.html',1,'']]],
  ['trie',['trie',['../namespacetrie.html',1,'']]]
];
